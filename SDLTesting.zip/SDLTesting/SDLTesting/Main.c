#include <stdio.h>
#include <SDL.h>
#include "Settings.h"
#include <math.h>

SDL_Window* SDLWindow = NULL;
SDL_Renderer* SDLRenderer = NULL;

int isRunning;

int R, G, B, A;

int last_Frame_Time = 0;

float ballSpeed = 300.f;
float paddleSpeed = 1000.f;

struct Rect {
	int posX;
	int posY;
	int width;
	int height;
} ball, paddle;

struct Direction {
	int x;
	int y;
} ballDirection;

// Initializes SDL Window and Renderer
int InitializeWindow(void);

// Cleans up SDL Window and Renderer
int DestroyWindow(void);

// Called at start of game
void Start();

// Called each Frame dedicated to Process Input
int ProcessInput();

// Called Each Frame dedicated to logical calculations
int Update();

// Called Each Frame dedicated to Rendering 
int Render();

int MovePaddle(float deltaTime, int direction);

int MoveBall(float deltaTime);

// Application Entry Point
int main() {
	isRunning = InitializeWindow();
	printf("Hello World!\n");
	
	Start();

	while (isRunning) {
		ProcessInput();
		Update();
		Render();
	}

	DestroyWindow();

	return 0;
}

int InitializeWindow(void)
{
	if (!SDL_Init(SDL_INIT_EVERYTHING)) {
		fprintf(stderr, "Error Initializing SDL!\n");
		return 0;
	}

	SDLWindow = SDL_CreateWindow(APP_NAME, SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, WINDOW_WIDTH, WINDOW_HEIGHT, SDL_WINDOW_BORDERLESS);
	if (!SDLWindow) {
		fprintf(stderr, "Error Initializing SDL!\n");
		return 0;
	}

	SDLRenderer = SDL_CreateRenderer(SDLWindow, -1, 0);
	
	if (!SDLRenderer) {
		fprintf(stderr, "Error Initializing SDL!\n");
		return 0;
	}

	return 1;
}

int DestroyWindow(void) {
	SDL_DestroyRenderer(SDLRenderer);
	SDL_DestroyWindow(SDLWindow);
	SDL_Quit();
}

void Start()
{
	R = G = B = A = 0;
	ball.posX = ball.posY = 0;
	ball.width = ball.height = 20;

	paddle.posX = WINDOW_WIDTH / 2;
	paddle.posY = (7 * WINDOW_HEIGHT) / 8;
	paddle.width = 150;
	paddle.height = 20;

	ballDirection.x = ballDirection.y = 1;
}

int ProcessInput()
{
	SDL_Event SDLEvent;
	SDL_PollEvent(&SDLEvent);

	if (SDLEvent.key.keysym.sym == SDLK_ESCAPE) {
		isRunning = 0;
	}
}

int Update()
{
	//CPU will burn
	//while (!SDL_TICKS_PASSED(SDL_GetTicks(), last_Frame_Time + TARGET_FRAME_TIME));

	int time_to_wait = TARGET_FRAME_TIME - (SDL_GetTicks() - last_Frame_Time);

	if (time_to_wait > 0 && time_to_wait <= TARGET_FRAME_TIME) {
		SDL_Delay(TARGET_FRAME_TIME);
	}

	float deltaTime = (SDL_GetTicks() - last_Frame_Time)/1000.f;

	last_Frame_Time = SDL_GetTicks();

	MoveBall(deltaTime);

	//ball.posX += (int)(deltaTime * ballSpeed);
	//ball.posY += (int)(deltaTime * ballSpeed);

	SDL_Event SDLEvent;
	SDL_PollEvent(&SDLEvent);

	if (SDLEvent.key.keysym.sym == SDLK_a) {
		MovePaddle(deltaTime, -1);
	}

	if (SDLEvent.key.keysym.sym == SDLK_d) {
		MovePaddle(deltaTime, 1);
	}

	if (ball.posX < paddle.posX + paddle.width && ball.posX + ball.width > paddle.posX && ball.posY < paddle.posY + paddle.height && ball.posY + ball.height > paddle.posY) {
		
		ballDirection.y *= -1;
	}
	

}

int Render()
{
	SDL_SetRenderDrawColor(SDLRenderer, R, G, B, A);
	SDL_RenderClear(SDLRenderer);

	SDL_Rect _ball = {
		ball.posX,
		ball.posY,
		ball.width,
		ball.height
	};

	SDL_Rect _paddle = {
		paddle.posX,
		paddle.posY,
		paddle.width,
		paddle.height
	};

	SDL_SetRenderDrawColor(SDLRenderer, 255, 0, 0, 255);
	SDL_RenderFillRect(SDLRenderer, &_ball);

	SDL_RenderFillRect(SDLRenderer, &_paddle);

	SDL_RenderPresent(SDLRenderer);
}

int MovePaddle(float deltaTime, int direction){

	paddle.posX += direction * paddleSpeed * deltaTime;

	if(paddle.posX + paddle.width > WINDOW_WIDTH) {
		paddle.posX = WINDOW_WIDTH - paddle.width;
		return 0;
	}
	else if (paddle.posX < 0) {
		paddle.posX = 0;
		return 0;
	}
}

int MoveBall(float deltaTime) {
	ball.posX += (int)(ballSpeed * ballDirection.x * deltaTime);
	ball.posY += (int)(ballSpeed * ballDirection.y * deltaTime);

	if (ball.posY + ball.height > WINDOW_HEIGHT || ball.posY < 0) {
		ballDirection.y *= -1;
	}
	if (ball.posX < 0 || ball.posX + ball.width > WINDOW_WIDTH) {
		ballDirection.x *= -1;
	}

}
