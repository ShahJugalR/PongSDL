#pragma once

#define WINDOW_HEIGHT 720

#define WINDOW_WIDTH 1280

#define APP_NAME "Appname"

#define TARGET_FPS 60

#define TARGET_FRAME_TIME (1000/TARGET_FPS)